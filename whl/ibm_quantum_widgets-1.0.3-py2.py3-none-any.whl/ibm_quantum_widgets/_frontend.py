#!/usr/bin/env python
# coding: utf-8

# Copyright (c) IBM Research.
# Distributed under the terms of the Modified BSD License.

"""
Information about the frontend package of the widgets.
"""

module_name = "@quantum/ibm-q-lab-widgets"
module_version = "^1.0.3"
