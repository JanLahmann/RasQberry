#!/usr/bin/env python
# coding: utf-8

# Copyright (c) IBM Research.
# Distributed under the terms of the Modified BSD License.

version_info = (1, 0, 3)
__version__ = ".".join(map(str, version_info))
